import {Router} from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import {z} from 'zod';
import User from '../models/User.js';
import {protect} from '../middleware/auth.js';
const router=Router();
const schema=z.object({name:z.string().trim().min(2).max(80),email:z.string().email().max(200),password:z.string().min(8).max(72)});
function issue(res,user){const token=jwt.sign({sub:user._id},process.env.JWT_SECRET,{expiresIn:process.env.JWT_EXPIRES_IN||'7d'});res.cookie('token',token,{httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'lax',maxAge:7*24*60*60*1000});return res.json({user:{id:user._id,name:user.name,email:user.email,role:user.role},token});}
router.post('/register',async(req,res,next)=>{try{const parsed=schema.safeParse(req.body);if(!parsed.success)return res.status(400).json({message:parsed.error.issues[0].message});const {name,email,password}=parsed.data;const normalized=email.toLowerCase();if(await User.findOne({email:normalized}))return res.status(409).json({message:'Email is already registered'});const user=await User.create({name,email:normalized,passwordHash:await bcrypt.hash(password,12)});issue(res,user);}catch(e){next(e);}});
router.post('/login',async(req,res,next)=>{try{const parsed=z.object({email:z.string().email(),password:z.string().min(1)}).safeParse(req.body);if(!parsed.success)return res.status(400).json({message:'Enter a valid email and password'});const user=await User.findOne({email:parsed.data.email.toLowerCase()});if(!user||!await bcrypt.compare(parsed.data.password,user.passwordHash))return res.status(401).json({message:'Invalid email or password'});issue(res,user);}catch(e){next(e);}});
router.post('/logout',(req,res)=>res.clearCookie('token',{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production'}).json({message:'Logged out'}));
router.get('/me',protect,(req,res)=>res.json({user:req.user}));
export default router;
