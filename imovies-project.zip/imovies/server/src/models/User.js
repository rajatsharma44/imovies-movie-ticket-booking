import mongoose from 'mongoose';
const userSchema = new mongoose.Schema({name:{type:String,required:true,trim:true,maxLength:80},email:{type:String,required:true,unique:true,lowercase:true,trim:true},passwordHash:{type:String,required:true},role:{type:String,enum:['user','admin'],default:'user'},favorites:[{type:mongoose.Schema.Types.ObjectId,ref:'Movie'}]}, {timestamps:true});
export default mongoose.model('User',userSchema);
