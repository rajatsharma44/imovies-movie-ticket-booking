import mongoose from 'mongoose';
const showSchema = new mongoose.Schema({movie:{type:mongoose.Schema.Types.ObjectId,ref:'Movie',required:true},theater:{type:String,required:true},location:{type:String,required:true},screen:{type:String,default:'Screen 1'},startsAt:{type:Date,required:true},endsAt:Date,price:{type:Number,required:true,min:0},rows:{type:Number,default:8},seatsPerRow:{type:Number,default:10},active:{type:Boolean,default:true}}, {timestamps:true});
export default mongoose.model('Show',showSchema);
