import mongoose from 'mongoose';
const movieSchema = new mongoose.Schema({title:{type:String,required:true,trim:true},description:{type:String,default:''},genre:[String],language:{type:String,default:'English'},duration:{type:Number,default:120},rating:{type:Number,min:0,max:10,default:0},poster:{type:String,default:''},banner:{type:String,default:''},releaseDate:Date,featured:{type:Boolean,default:false},active:{type:Boolean,default:true}}, {timestamps:true});
export default mongoose.model('Movie',movieSchema);
