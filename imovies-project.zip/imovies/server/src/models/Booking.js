import mongoose from 'mongoose';
const bookingSchema = new mongoose.Schema({user:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true},show:{type:mongoose.Schema.Types.ObjectId,ref:'Show',required:true},movie:{type:mongoose.Schema.Types.ObjectId,ref:'Movie',required:true},seats:[String],amount:{type:Number,required:true},status:{type:String,enum:['pending','confirmed','cancelled','payment_failed'],default:'pending'},paymentStatus:{type:String,enum:['pending','paid','failed','refunded'],default:'pending'},paymentReference:String,lockExpiresAt:Date}, {timestamps:true});
bookingSchema.index({show:1,seats:1,status:1});
export default mongoose.model('Booking',bookingSchema);
