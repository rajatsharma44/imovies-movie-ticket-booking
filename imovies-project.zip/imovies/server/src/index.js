import 'dotenv/config';
import express from 'express';
import http from 'node:http';
import mongoose from 'mongoose';
import cors from 'cors';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import {Server} from 'socket.io';
import authRoutes from './routes/auth.js';
import movieRoutes from './routes/movies.js';
import bookingRoutes from './routes/bookings.js';
const app=express();const server=http.createServer(app);
const io=new Server(server,{cors:{origin:process.env.CLIENT_URL||'http://localhost:5173',credentials:true}});
app.set('io',io);app.use(helmet());app.use(cors({origin:process.env.CLIENT_URL||'http://localhost:5173',credentials:true}));app.use(express.json({limit:'100kb'}));app.use(cookieParser());app.use('/api',rateLimit({windowMs:15*60*1000,limit:300,standardHeaders:true,legacyHeaders:false}));
app.get('/api/health',(req,res)=>res.json({status:'ok',service:'iMovies API'}));app.use('/api/auth',authRoutes);app.use('/api/movies',movieRoutes);app.use('/api/bookings',bookingRoutes);
app.use((err,req,res,next)=>{console.error(err);if(err.name==='ZodError')return res.status(400).json({message:err.issues?.[0]?.message||'Invalid input'});if(err.code===11000)return res.status(409).json({message:'A record with this value already exists'});res.status(err.status||500).json({message:err.status?err.message:'Server error'});});
const port=process.env.PORT||5000;
try{await mongoose.connect(process.env.MONGODB_URI||'mongodb://127.0.0.1:27017/imovies');server.listen(port,()=>console.log(`iMovies API running on http://localhost:${port}`));}catch(err){console.error('MongoDB connection failed:',err.message);process.exit(1);}
