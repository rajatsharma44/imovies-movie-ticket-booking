import { z } from 'zod';
import Review from '../models/Review.js';
import Movie from '../models/Movie.js';

export async function listReviews(req,res,next){
  try {
    const filter={movie:req.params.movieId,status:'published'};
    const reviews=await Review.find(filter).populate('user','username name').sort({createdAt:-1}).limit(100);
    res.json(reviews);
  } catch(error){next(error);}
}
export async function createReview(req,res,next){
  try {
    const body=z.object({rating:z.number().min(1).max(10),comment:z.string().trim().max(1200).optional().default('')}).parse(req.body);
    if(!await Movie.exists({_id:req.params.movieId,active:true})) return res.status(404).json({message:'Movie not found'});
    const review=await Review.findOneAndUpdate({user:req.user._id,movie:req.params.movieId},{$set:{...body,status:'published'}},{new:true,upsert:true,runValidators:true,setDefaultsOnInsert:true});
    const stats=await Review.aggregate([{$match:{movie:review.movie,status:'published'}},{$group:{_id:'$movie',average:{$avg:'$rating'},count:{$sum:1}}}]);
    if(stats[0]) await Movie.findByIdAndUpdate(review.movie,{rating:Math.round(stats[0].average*10)/10,reviewCount:stats[0].count});
    res.status(201).json(review);
  } catch(error){next(error);}
}
export async function moderateReview(req,res,next){
  try {
    const body=z.object({status:z.enum(['published','hidden'])}).parse(req.body);
    const review=await Review.findByIdAndUpdate(req.params.id,{status:body.status},{new:true,runValidators:true});
    if(!review)return res.status(404).json({message:'Review not found'});
    res.json(review);
  }catch(error){next(error);}
}
