import {Router} from 'express';
import {protect,adminOnly} from '../middleware/auth.js';
import User from '../models/User.js';
import Admin from '../models/Admin.js';
import Movie from '../models/Movie.js';
import Show from '../models/Show.js';
import Booking from '../models/Booking.js';
import Review from '../models/Review.js';
const router=Router();
router.use(protect,adminOnly);
router.get('/reports',async(req,res,next)=>{try{
 const [users,admins,movies,shows,bookings,reviewCount,revenueRows,bookingStatuses]=await Promise.all([
  User.countDocuments(),Admin.countDocuments(),Movie.countDocuments({active:true}),Show.countDocuments({active:true}),Booking.countDocuments(),Review.countDocuments(),
  Booking.aggregate([{$match:{paymentStatus:'paid'}},{$group:{_id:null,total:{$sum:'$amount'}}}]),
  Booking.aggregate([{$group:{_id:'$status',count:{$sum:1}}}])
 ]);
 res.json({users,admins,movies,shows,bookings,reviews:reviewCount,revenue:revenueRows[0]?.total||0,bookingStatuses});
 }catch(e){next(e);}});
router.get('/users',async(req,res,next)=>{try{res.json(await User.find().select('username name email createdAt').sort({createdAt:-1}).limit(500));}catch(e){next(e);}});
export default router;
