import {Router} from 'express';
import {protect} from '../middleware/auth.js';
import Notification from '../models/Notification.js';
const router=Router();
router.get('/',protect,async(req,res,next)=>{try{res.json(await Notification.find({user:req.user._id}).sort({createdAt:-1}).limit(100));}catch(e){next(e);}});
router.patch('/:id/read',protect,async(req,res,next)=>{try{const item=await Notification.findOneAndUpdate({_id:req.params.id,user:req.user._id},{$set:{readAt:new Date()}},{new:true});if(!item)return res.status(404).json({message:'Notification not found'});res.json(item);}catch(e){next(e);}});
export default router;
