import crypto from 'node:crypto';
import Razorpay from 'razorpay';
export async function createPayment(amount, receipt){
  if(process.env.PAYMENT_MODE==='razorpay' && process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET){const gateway=new Razorpay({key_id:process.env.RAZORPAY_KEY_ID,key_secret:process.env.RAZORPAY_KEY_SECRET});return {mode:'razorpay',keyId:process.env.RAZORPAY_KEY_ID,order:await gateway.orders.create({amount:Math.round(amount*100),currency:'INR',receipt})};}
  return {mode:'mock',order:{id:`mock_${crypto.randomUUID()}`,amount:Math.round(amount*100),currency:'INR',receipt},message:'Development payment only. No money is charged.'};
}
export function verifyRazorpaySignature(orderId,paymentId,signature){const expected=crypto.createHmac('sha256',process.env.RAZORPAY_KEY_SECRET).update(`${orderId}|${paymentId}`).digest('hex');return crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(signature||''));}
