import mongoose from 'mongoose';
const reviewSchema = new mongoose.Schema({
  user:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true,index:true},
  movie:{type:mongoose.Schema.Types.ObjectId,ref:'Movie',required:true,index:true},
  rating:{type:Number,required:true,min:1,max:10},
  comment:{type:String,trim:true,maxLength:1200,default:''},
  status:{type:String,enum:['published','hidden'],default:'published',index:true}
},{timestamps:true});
reviewSchema.index({user:1,movie:1},{unique:true});
export default mongoose.model('Review',reviewSchema);
