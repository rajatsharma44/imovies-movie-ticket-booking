import mongoose from 'mongoose';
const showSchema = new mongoose.Schema({
  showId:{type:String,trim:true}, adminEmail:{type:String,lowercase:true,trim:true,default:''},
  movie:{type:mongoose.Schema.Types.ObjectId,ref:'Movie',required:true}, movieId:{type:mongoose.Schema.Types.ObjectId,ref:'Movie'},
  theatre:{type:mongoose.Schema.Types.ObjectId,ref:'Theatre'}, theatreName:{type:String,trim:true}, theater:{type:String,trim:true},
  location:{type:String,required:true}, screen:{type:String,default:'Screen 1'},
  showDate:{type:Date}, showTime:{type:String}, startsAt:{type:Date,required:true}, endsAt:Date,
  tickets:{type:Number,default:0,min:0}, price:{type:Number,required:true,min:0}, rows:{type:Number,default:8,min:1,max:20}, seatsPerRow:{type:Number,default:10,min:1,max:20}, active:{type:Boolean,default:true}
},{timestamps:true});
showSchema.pre('validate',function(next){this.movieId=this.movieId||this.movie;this.theatreName=this.theatreName||this.theater||'';this.theater=this.theater||this.theatreName;this.showDate=this.showDate||this.startsAt;this.showTime=this.showTime||new Date(this.startsAt).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'});this.showId=this.showId||this._id?.toString();next();});
showSchema.index({movie:1,startsAt:1});
export default mongoose.model('Show',showSchema);
