import mongoose from 'mongoose';
const notificationSchema = new mongoose.Schema({
  user:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true,index:true},
  type:{type:String,enum:['booking_confirmation','payment_receipt','show_reminder','movie_update','system'],default:'system'},
  title:{type:String,required:true,trim:true,maxLength:160},
  message:{type:String,required:true,trim:true,maxLength:1200},
  readAt:{type:Date,default:null},
  metadata:{type:mongoose.Schema.Types.Mixed,default:{}}
},{timestamps:true});
export default mongoose.model('Notification',notificationSchema);
