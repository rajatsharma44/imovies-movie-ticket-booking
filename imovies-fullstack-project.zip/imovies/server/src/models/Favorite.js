import mongoose from 'mongoose';
const favoriteSchema=new mongoose.Schema({userEmail:{type:String,required:true,lowercase:true,trim:true,index:true},user:{type:mongoose.Schema.Types.ObjectId,ref:'User'},movieId:{type:mongoose.Schema.Types.ObjectId,ref:'Movie',required:true}},{timestamps:true});
favoriteSchema.index({userEmail:1,movieId:1},{unique:true});
export default mongoose.model('Favorite',favoriteSchema);
