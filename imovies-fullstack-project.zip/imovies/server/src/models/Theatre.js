import mongoose from 'mongoose';
const theatreSchema=new mongoose.Schema({theatreName:{type:String,required:true,trim:true},adminName:{type:String,default:''},location:{type:String,required:true,trim:true},theatreId:{type:String,trim:true},lowerSeats:{type:Number,default:0,min:0},middleSeats:{type:Number,default:0,min:0},balconySeats:{type:Number,default:0,min:0},lowerSeatPrice:{type:Number,default:0,min:0},middleSeatPrice:{type:Number,default:0,min:0},balconySeatPrice:{type:Number,default:0,min:0},active:{type:Boolean,default:true}},{timestamps:true});
theatreSchema.index({theatreName:1,location:1},{unique:true});
export default mongoose.model('Theatre',theatreSchema);
