import mongoose from 'mongoose';
const adminSchema = new mongoose.Schema({username:{type:String,required:true,trim:true,minLength:2,maxLength:80},email:{type:String,required:true,unique:true,lowercase:true,trim:true,index:true},passwordHash:{type:String,required:true,select:false},role:{type:String,default:'admin',enum:['admin']}},{timestamps:true});
export default mongoose.model('Admin',adminSchema);
