import mongoose from 'mongoose';
const userSchema = new mongoose.Schema({
  username:{type:String,required:true,trim:true,minLength:2,maxLength:80},
  name:{type:String,trim:true,maxLength:80},
  email:{type:String,required:true,unique:true,lowercase:true,trim:true,index:true},
  passwordHash:{type:String,required:true,select:false},
  role:{type:String,enum:['user'],default:'user'}
},{timestamps:true});
userSchema.pre('validate',function(next){if(!this.name)this.name=this.username; if(!this.username)this.username=this.name; next();});
export default mongoose.model('User',userSchema);
