import mongoose from 'mongoose';
const movieSchema = new mongoose.Schema({
  movieName:{type:String,trim:true}, title:{type:String,trim:true}, description:{type:String,default:''},
  media:{type:String,default:''}, poster:{type:String,default:''}, banner:{type:String,default:''},
  certification:{type:String,default:'U/A'}, runtime:{type:Number,default:120,min:1}, duration:{type:Number,min:1},
  genres:[String], genre:[String], language:{type:String,default:'English'}, rating:{type:Number,min:0,max:10,default:0}, reviewCount:{type:Number,min:0,default:0},
  releaseDate:Date, shows:[{type:mongoose.Schema.Types.ObjectId,ref:'Show'}], featured:{type:Boolean,default:false}, active:{type:Boolean,default:true}
},{timestamps:true,toJSON:{virtuals:true},toObject:{virtuals:true}});
movieSchema.pre('validate',function(next){this.title=this.title||this.movieName;this.movieName=this.movieName||this.title;this.genre=this.genre?.length?this.genre:(this.genres||[]);this.genres=this.genres?.length?this.genres:(this.genre||[]);this.duration=this.duration||this.runtime;this.runtime=this.runtime||this.duration;this.poster=this.poster||this.media;this.media=this.media||this.poster;next();});
movieSchema.virtual('movieId').get(function(){return this._id.toString();});
export default mongoose.model('Movie',movieSchema);
