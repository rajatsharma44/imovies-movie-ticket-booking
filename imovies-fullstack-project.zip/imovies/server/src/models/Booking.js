import mongoose from 'mongoose';
const bookingSchema = new mongoose.Schema({
  bookingId:{type:String,trim:true}, user:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true}, userEmail:{type:String,lowercase:true,trim:true},
  show:{type:mongoose.Schema.Types.ObjectId,ref:'Show',required:true}, showId:{type:mongoose.Schema.Types.ObjectId,ref:'Show'},
  movie:{type:mongoose.Schema.Types.ObjectId,ref:'Movie',required:true}, ticketsData:{type:mongoose.Schema.Types.Mixed,default:[]},
  seats:[String], amount:{type:Number,required:true,min:0}, status:{type:String,enum:['pending','confirmed','cancelled','payment_failed'],default:'pending'},
  paymentStatus:{type:String,enum:['pending','paid','failed','refunded'],default:'pending'},paymentReference:String,lockExpiresAt:Date
},{timestamps:true});
bookingSchema.pre('validate',function(next){this.bookingId=this.bookingId||this._id?.toString();this.showId=this.showId||this.show;this.ticketsData=this.ticketsData?.length?this.ticketsData:this.seats;next();});
bookingSchema.index({show:1,seats:1,status:1});bookingSchema.index({user:1,createdAt:-1});
export default mongoose.model('Booking',bookingSchema);
