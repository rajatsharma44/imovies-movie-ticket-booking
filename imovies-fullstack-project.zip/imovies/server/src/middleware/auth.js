import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import Admin from '../models/Admin.js';
export async function protect(req,res,next){try{const token=req.cookies?.token||(req.headers.authorization?.startsWith('Bearer ')?req.headers.authorization.slice(7):null);if(!token)return res.status(401).json({message:'Authentication required'});const payload=jwt.verify(token,process.env.JWT_SECRET);let account=await User.findById(payload.sub);if(account){req.user=account;req.user.role='user';}else{account=await Admin.findById(payload.sub);if(!account)return res.status(401).json({message:'Account not found'});req.user=account;req.user.role='admin';}next();}catch{return res.status(401).json({message:'Invalid or expired session'});}}
export function adminOnly(req,res,next){if(req.user?.role!=='admin')return res.status(403).json({message:'Admin access required'});next();}
