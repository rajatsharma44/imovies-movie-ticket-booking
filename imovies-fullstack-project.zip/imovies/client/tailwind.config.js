export default {content:['./index.html','./src/**/*.{js,jsx}'],theme:{extend:{colors:{accent:'#f43f5e',surface:'#17171c'}}},plugins:[]};
