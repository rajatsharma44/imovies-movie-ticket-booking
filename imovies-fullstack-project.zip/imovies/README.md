# iMovies — Online Movie Ticket Booking System

A full-stack movie ticket booking project built with React + Vite, Node.js + Express, MongoDB/Mongoose, JWT authentication, bcrypt password hashing, seat availability checks, and a mock/Razorpay payment service.

## Features

- Responsive dark cinema-themed UI with movie search and genre filters.
- Registration, login, logout, profile session check, JWT bearer auth and HTTP-only cookie support.
- Movies and showtimes backed by MongoDB.
- Seat map with available/unavailable states and five-minute temporary holds.
- Booking history, cancellation, and booking reference.
- Mock payment flow for local development; Razorpay order creation can be enabled using environment variables.
- Admin forms for creating movies and showtimes.
- Helmet security headers, CORS allowlist, rate limiting, Zod input validation, bcrypt password hashes, and role-based admin access.
- Socket.io server is initialized for future real-time seat update events.

## Requirements

- Node.js 20 or later recommended
- npm
- MongoDB Atlas (recommended) or a local MongoDB replica set. The booking endpoint uses MongoDB transactions to avoid conflicting seat reservations; standalone local MongoDB does not support transactions.

## Quick start

1. Install Node.js and make sure MongoDB Atlas or a local replica-set MongoDB is running.
2. Open a terminal in the project folder.
3. Install root and app dependencies:

   ```bash
   npm install
   npm run install:all
   ```

4. Copy `server/.env.example` to `server/.env`, then set `MONGODB_URI` and replace `JWT_SECRET` with a long random value. Keep `PAYMENT_MODE=mock` for local testing.
5. Optional: copy `client/.env.example` to `client/.env`. The default API URL is `http://localhost:5000/api`.
6. Seed demo movies and showtimes:

   ```bash
   npm run seed --prefix server
   ```

7. Start both apps:

   ```bash
   npm run dev
   ```

8. Open <http://localhost:5173>. The API health endpoint is <http://localhost:5000/api/health>.

## Create an admin account

Register normally in the app first. Then, in your MongoDB database, update that user's `role` to `admin` in the `users` collection. For example, in `mongosh`:

```javascript
use imovies
db.users.updateOne({ email: "your-email@example.com" }, { $set: { role: "admin" } })
```

Sign out and sign in again so the UI refreshes the role. Never expose admin role changes as a public API.

## Payment setup

### Mock development mode

`PAYMENT_MODE=mock` is the default. It creates a simulated order and lets you confirm a booking without charging money. The UI explicitly labels this as development behavior. Do not use mock mode for production ticket sales.

### Razorpay order creation

Set these in `server/.env`:

```env
PAYMENT_MODE=razorpay
RAZORPAY_KEY_ID=your_key_id
RAZORPAY_KEY_SECRET=your_key_secret
```

The app creates Razorpay orders, opens Razorpay Checkout in the browser, and verifies the signed response on the server before confirming a booking. Before production, add webhook handling with idempotency and reconcile gateway state if a browser closes mid-payment. Refund status in this demo is a record state only; connect it to the gateway refund API before processing real payments.

## API overview

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| GET | `/api/health` | Public | Health check |
| POST | `/api/auth/register` | Public | Create account |
| POST | `/api/auth/login` | Public | Sign in |
| POST | `/api/auth/logout` | Public | Clear session cookie |
| GET | `/api/auth/me` | Signed in | Current user |
| GET | `/api/movies` | Public | List/search/filter movies |
| GET | `/api/movies/:id/shows` | Public | Upcoming shows for a movie |
| POST | `/api/movies` | Admin | Create movie |
| POST | `/api/movies/:id/shows` | Admin | Create show |
| GET | `/api/bookings/show/:showId/seats` | Signed in | Seat map and availability |
| POST | `/api/bookings` | Signed in | Lock seats and create pending booking/order |
| POST | `/api/bookings/:id/confirm-mock` | Signed in, mock mode | Confirm development payment |
| POST | `/api/bookings/:id/verify-razorpay` | Signed in, Razorpay mode | Verify signed gateway payment and confirm booking |
| GET | `/api/bookings/mine` | Signed in | User booking history |
| POST | `/api/bookings/:id/cancel` | Booking owner | Cancel booking |
| GET | `/api/bookings` | Admin | List bookings |

## Deployment notes

- Frontend: deploy `client` to Vercel or Netlify; set `VITE_API_URL` to the deployed API URL.
- Backend: deploy `server` to Render, Railway, or AWS; set all server environment variables and use a managed MongoDB Atlas cluster.
- Set `CLIENT_URL` to the exact deployed frontend origin, use HTTPS, and set `NODE_ENV=production`.
- For cross-site frontend/backend deployments, review cookie `SameSite`/`Secure` settings and use an appropriate session strategy. Prefer secure, HTTP-only cookies; avoid storing long-lived bearer tokens in localStorage in production.
- Add monitoring, automated tests, a production payment webhook, email/SMS notifications, and a real-time Socket.io room/event flow before launch.

## Important implementation notes

This is a runnable educational starter, not a certified production ticketing platform. The booking endpoint uses MongoDB transactions; deploy against a replica set (Atlas qualifies). Seat holds expire logically after five minutes; expired pending booking records are retained for history but no longer block seats. For high-concurrency production use, consider a dedicated seat-lock collection with a unique `(showId, seatId)` index and TTL cleanup. Do not trust client totals or payment status in a production payment flow.

## ER-diagram-aligned MongoDB design

The backend now maps the uploaded ER diagram into dedicated Mongoose models:

- **User**: `username`, `email`, hashed `passwordHash` (password is never stored in plaintext).
- **Admin**: separate admin collection with `username`, `email`, hashed `passwordHash`, and admin role. Admin accounts are not created by public signup.
- **Movie**: `movieName`/`title`, `media`/`poster`, `certification`, `runtime`/`duration`, `genres`/`genre`, `releaseDate`, `description`, and a `shows` reference list. Compatibility aliases are maintained for the existing UI.
- **Show**: references a Movie and Theatre; includes `showId`, `adminEmail`, `theatreName`, `showDate`, `showTime`, ticket count, price, and seat layout.
- **Booking**: references User, Show, and Movie; includes `bookingId`, `userEmail`, `showId`, `ticketsData`, seats, amount, payment state, and seat-lock expiry.
- **Theatre**: `theatreName`, `adminName`, `location`, `theatreId`, lower/middle/balcony seat counts, and per-section seat prices.
- **Favorite**: a separate collection linking `userEmail`/User and `movieId`, with a unique index to prevent duplicate favorites.

### New API endpoints

- `GET /api/theatres` — list active theatres; optional `?location=Bhopal` filter.
- `GET /api/theatres/:id/shows` — list upcoming shows at a theatre.
- `POST /api/theatres` — admin-only theatre creation.
- `PATCH /api/theatres/:id` — admin-only theatre update.
- `GET /api/favorites` — list the signed-in user's favorites.
- `POST /api/favorites` with `{ "movieId": "<MongoDB ObjectId>" }` — add a favorite.
- `DELETE /api/favorites/:movieId` — remove a favorite.
- Existing movie, show, booking, and authentication endpoints remain available.

### Admin account setup

Public registration creates ordinary User accounts only. To create the first Admin, run this once from the `server` folder after setting `MONGODB_URI` and `JWT_SECRET` in `.env`:

```bash
node --input-type=module -e "import 'dotenv/config'; import mongoose from 'mongoose'; import bcrypt from 'bcryptjs'; import Admin from './src/models/Admin.js'; await mongoose.connect(process.env.MONGODB_URI); const email=process.env.INITIAL_ADMIN_EMAIL; const password=process.env.INITIAL_ADMIN_PASSWORD; const username=process.env.INITIAL_ADMIN_USERNAME || 'admin'; if(!email || !password || password.length<12) throw new Error('Set INITIAL_ADMIN_EMAIL and INITIAL_ADMIN_PASSWORD (at least 12 characters) in .env'); await Admin.create({username,email,passwordHash:await bcrypt.hash(password,12)}); console.log('Admin account created'); await mongoose.disconnect();"
```

Set `INITIAL_ADMIN_EMAIL`, `INITIAL_ADMIN_PASSWORD`, and optionally `INITIAL_ADMIN_USERNAME` in the server `.env` before running it. Keep these secrets private and remove them from the environment after setup. MongoDB transactions used by seat booking require a replica set; MongoDB Atlas provides this by default. For local development, use a local replica-set configuration or adapt the booking transaction flow before using a standalone MongoDB server.

## Additional modules: reviews, notifications, and reports

The backend follows an MVC-style structure: Mongoose schemas live in `server/src/models`, request handlers live in `server/src/controllers`, and REST endpoints live in `server/src/routes`.

### Reviews and ratings

- `GET /api/reviews/movie/:movieId` — list published reviews for a movie.
- `POST /api/reviews/movie/:movieId` — authenticated user creates or updates their review. JSON body: `{ "rating": 8, "comment": "Great movie" }` (rating range 1–10).
- `GET /api/reviews/admin/all` — admin review moderation queue.
- `PATCH /api/reviews/:id/moderate` — admin hides or republishes a review with `{ "status": "hidden" }` or `{ "status": "published" }`.

A unique index ensures one review per user per movie. Published review averages update the movie rating and review count.

### Notifications

- `GET /api/notifications` — authenticated user's notifications.
- `PATCH /api/notifications/:id/read` — mark a notification as read.

Notification records can represent booking confirmations, payment receipts, show reminders, movie updates, and system alerts. Email/SMS delivery requires configuring a provider; the included API stores and serves in-app notifications and does not claim to send external email or SMS by itself.

### Admin reporting

- `GET /api/admin/reports` — counts users, admins, active movies, active shows, bookings, reviews, booking statuses, and recorded paid-booking revenue.
- `GET /api/admin/users` — admin-only user list (password hashes are never returned).

These endpoints require an authenticated administrator. To use real payments, configure the payment provider credentials and verify payment webhooks server-side before marking a booking paid. Mock payment mode is for development only.

### MVC folder layout

```text
server/src/
├── models/        # MongoDB/Mongoose schemas
├── controllers/   # request handling and business logic
├── routes/        # REST API endpoints
├── middleware/    # authentication and authorization
└── services/      # payment integration and reusable services
```
